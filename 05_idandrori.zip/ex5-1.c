int mystery(short a, short b, short c) // becuase short is word like in the original function
{
  return b * b - 4 * a * c;
}

int main(void)
{
  return 0;
}
